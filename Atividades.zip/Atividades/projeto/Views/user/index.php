<div class="container pt-4 pb-5 bg-light">
    <h2 class="border-bottom border-2 border-primary">
         Página do Cliente
    </h2>

    <?php print_r($_SESSION['usuario_logado']) ?>
</div>