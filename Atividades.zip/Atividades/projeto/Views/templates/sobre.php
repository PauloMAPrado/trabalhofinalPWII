<!-- Abre Sobre -->
<div id="sobre" class="container-fluid bg-light mt-5 mb-5 pt-3 pb-3">
            <div class="container">

                <img width="200" src="<?php base_url('assets/images/sd_logo.png') ?>"
                    class="m-4 float-end">

                <h1>Conheça a nossa História</h1>

                <p class=" text-justify">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem
                    in, ex veniam error magni quae pariatur minus recusandae non
                    nihil inventore consequuntur illo, ducimus, optio aliquid!
                    Maxime ut dolorum reprehenderit!

                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem
                    in, ex veniam error magni quae pariatur minus recusandae non
                    nihil inventore consequuntur illo, ducimus, optio aliquid!
                    Maxime ut dolorum reprehenderit!
                    </p class="text-justify">

                    <p class="text-justify">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Rem in, ex veniam error magni quae pariatur minus
                        recusandae non nihil inventore consequuntur illo,
                        ducimus, optio aliquid! Maxime ut dolorum reprehenderit!
                    </p>

                    <p class="text-justify">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Rem in, ex veniam error magni quae pariatur minus
                        recusandae non nihil inventore consequuntur illo,
                        ducimus, optio aliquid! Maxime ut dolorum reprehenderit!
                    </p>
                </div>

            </div>

            <!-- Fecha Sobre -->